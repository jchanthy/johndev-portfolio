    <footer class="main-footer">
        <div class="container footer-content">
            <div class="footer-left">
                <p>&copy; <?php echo date('Y'); ?> JohnDev. Built with security in mind.</p>
            </div>
            <div class="footer-right">
                <a href="#">GitHub</a>
                <a href="#">LinkedIn</a>
                <a href="#">Twitter</a>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
</body>
</html>
