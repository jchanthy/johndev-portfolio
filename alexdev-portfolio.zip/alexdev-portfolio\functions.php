<?php
function john_portfolio_scripts() {
    wp_enqueue_style( 'john-portfolio-style', get_stylesheet_uri() );
    wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&family=JetBrains+Mono:wght@400;700&display=swap', array(), null );
    wp_enqueue_script( 'john-portfolio-script', get_template_directory_uri() . '/js/script.js', array(), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'john_portfolio_scripts' );

function john_portfolio_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
}
add_action( 'after_setup_theme', 'john_portfolio_setup' );

// Register Project Custom Post Type
function john_portfolio_register_project_cpt() {
    $labels = array(
        'name'                  => _x( 'Projects', 'Post Type General Name', 'alexdev-portfolio' ),
        'singular_name'         => _x( 'Project', 'Post Type Singular Name', 'alexdev-portfolio' ),
        'menu_name'             => __( 'Projects', 'alexdev-portfolio' ),
        'name_admin_bar'        => __( 'Project', 'alexdev-portfolio' ),
        'archives'              => __( 'Project Archives', 'alexdev-portfolio' ),
        'attributes'            => __( 'Project Attributes', 'alexdev-portfolio' ),
        'parent_item_colon'     => __( 'Parent Project:', 'alexdev-portfolio' ),
        'all_items'             => __( 'All Projects', 'alexdev-portfolio' ),
        'add_new_item'          => __( 'Add New Project', 'alexdev-portfolio' ),
        'add_new'               => __( 'Add New', 'alexdev-portfolio' ),
        'new_item'              => __( 'New Project', 'alexdev-portfolio' ),
        'edit_item'             => __( 'Edit Project', 'alexdev-portfolio' ),
        'update_item'           => __( 'Update Project', 'alexdev-portfolio' ),
        'view_item'             => __( 'View Project', 'alexdev-portfolio' ),
        'view_items'            => __( 'View Projects', 'alexdev-portfolio' ),
        'search_items'          => __( 'Search Project', 'alexdev-portfolio' ),
        'not_found'             => __( 'Not found', 'alexdev-portfolio' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'alexdev-portfolio' ),
        'featured_image'        => __( 'Project Image', 'alexdev-portfolio' ),
        'set_featured_image'    => __( 'Set project image', 'alexdev-portfolio' ),
        'remove_featured_image' => __( 'Remove project image', 'alexdev-portfolio' ),
        'use_featured_image'    => __( 'Use as project image', 'alexdev-portfolio' ),
        'insert_into_item'      => __( 'Insert into project', 'alexdev-portfolio' ),
        'uploaded_to_this_item' => __( 'Uploaded to this project', 'alexdev-portfolio' ),
        'items_list'            => __( 'Projects list', 'alexdev-portfolio' ),
        'items_list_navigation' => __( 'Projects list navigation', 'alexdev-portfolio' ),
        'filter_items_list'     => __( 'Filter projects list', 'alexdev-portfolio' ),
    );
    $args = array(
        'label'                 => __( 'Project', 'alexdev-portfolio' ),
        'description'           => __( 'Portfolio Projects', 'alexdev-portfolio' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
        'taxonomies'            => array( 'technology' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-portfolio',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
    );
    register_post_type( 'project', $args );
}
add_action( 'init', 'john_portfolio_register_project_cpt', 0 );

// Register Technology Taxonomy
function john_portfolio_register_technology_taxonomy() {
    $labels = array(
        'name'                       => _x( 'Technologies', 'Taxonomy General Name', 'alexdev-portfolio' ),
        'singular_name'              => _x( 'Technology', 'Taxonomy Singular Name', 'alexdev-portfolio' ),
        'menu_name'                  => __( 'Technologies', 'alexdev-portfolio' ),
        'all_items'                  => __( 'All Technologies', 'alexdev-portfolio' ),
        'parent_item'                => __( 'Parent Technology', 'alexdev-portfolio' ),
        'parent_item_colon'          => __( 'Parent Technology:', 'alexdev-portfolio' ),
        'new_item_name'              => __( 'New Technology Name', 'alexdev-portfolio' ),
        'add_new_item'               => __( 'Add New Technology', 'alexdev-portfolio' ),
        'edit_item'                  => __( 'Edit Technology', 'alexdev-portfolio' ),
        'update_item'                => __( 'Update Technology', 'alexdev-portfolio' ),
        'view_item'                  => __( 'View Technology', 'alexdev-portfolio' ),
        'separate_items_with_commas' => __( 'Separate technologies with commas', 'alexdev-portfolio' ),
        'add_or_remove_items'        => __( 'Add or remove technologies', 'alexdev-portfolio' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'alexdev-portfolio' ),
        'popular_items'              => __( 'Popular Technologies', 'alexdev-portfolio' ),
        'search_items'               => __( 'Search Technologies', 'alexdev-portfolio' ),
        'not_found'                  => __( 'Not Found', 'alexdev-portfolio' ),
        'no_terms'                   => __( 'No technologies', 'alexdev-portfolio' ),
        'items_list'                 => __( 'Technologies list', 'alexdev-portfolio' ),
        'items_list_navigation'      => __( 'Technologies list navigation', 'alexdev-portfolio' ),
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => false,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'technology', array( 'project' ), $args );
}
add_action( 'init', 'john_portfolio_register_technology_taxonomy', 0 );
?>
